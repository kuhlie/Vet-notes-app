import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Stethoscope } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8 bg-slate-50">
      <Card className="max-w-md w-full">
        <CardContent className="pt-6">
          <div className="text-center">
            <div className="mx-auto h-16 w-16 bg-primary rounded-xl flex items-center justify-center mb-6">
              <Stethoscope className="text-white text-2xl" size={24} />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">VetRecord Pro</h2>
            <p className="text-gray-600 mb-8">Secure consultation recording and transcription</p>
            
            <Button 
              onClick={handleLogin}
              className="w-full py-3 text-sm font-medium"
              size="lg"
            >
              Sign In
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
