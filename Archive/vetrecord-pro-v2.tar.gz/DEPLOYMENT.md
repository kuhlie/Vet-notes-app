# Deployment Guide - VetRecord Pro

## Quick Start for Replit Deployment

### 1. Import to Replit
1. Upload the `vetrecord-pro.tar.gz` file to a new Replit project
2. Extract the contents: `tar -xzf vetrecord-pro.tar.gz`
3. Copy all files to the root directory

### 2. Set up Environment Secrets
In Replit, go to Secrets (lock icon) and add:
```
DATABASE_URL=your_postgresql_connection_string
OPENAI_API_KEY=your_openai_api_key
SESSION_SECRET=generate_random_32_char_string
```

### 3. Database Setup
1. Provision a PostgreSQL database in Replit
2. Run the database schema: `psql $DATABASE_URL -f database-schema.sql`
3. Push schema with Drizzle: `npm run db:push`

### 4. Install Dependencies
```bash
npm install
```

### 5. Run the Application
```bash
npm run dev
```

## Production Deployment Options

### Option 1: Railway
1. Connect your GitHub repository to Railway
2. Add environment variables in Railway dashboard
3. Deploy automatically on push

### Option 2: Vercel + PlanetScale
1. Deploy frontend to Vercel
2. Use PlanetScale for database
3. Configure environment variables

### Option 3: DigitalOcean App Platform
1. Create new app from GitHub repository
2. Configure build and run commands
3. Add environment variables

## Environment Variables Reference

| Variable | Description | Required |
|----------|-------------|----------|
| DATABASE_URL | PostgreSQL connection string | Yes |
| OPENAI_API_KEY | OpenAI API key for transcription | Yes |
| SESSION_SECRET | Random string for session encryption | Yes |
| REPL_ID | Replit app ID (auto-provided) | Yes (Replit) |
| REPLIT_DOMAINS | Your app domain (auto-provided) | Yes (Replit) |

## Database Migration

After deployment, run:
```bash
npm run db:push
```

This will create all necessary tables in your database.

## Health Checks

The application provides these endpoints for monitoring:
- `GET /` - Frontend application
- `GET /api/auth/user` - Authentication status
- Database connectivity is checked on startup

## Scaling Considerations

- Use connection pooling for database
- Consider CDN for audio file storage
- Monitor OpenAI API usage and costs
- Implement rate limiting for API endpoints

## Security Notes

- All API endpoints require authentication
- Audio files are user-scoped
- Database uses proper foreign key constraints
- Session data is encrypted and secure