# Quick Installation Guide

## For Replit (Recommended)

1. **Create New Repl**
   - Upload `vetrecord-pro-v2.tar.gz` to a new Replit project
   - Extract: `tar -xzf vetrecord-pro-v2.tar.gz`

2. **Set Environment Secrets**
   - Click the lock icon (Secrets) in Replit
   - Add these secrets:
     ```
     OPENAI_API_KEY=your_openai_key_here
     SESSION_SECRET=random_32_character_string
     ```

3. **Database Setup**
   - Add PostgreSQL database from Replit Database tab
   - Run: `psql $DATABASE_URL -f database-schema.sql`
   - Run: `npm run db:push`

4. **Install & Run**
   ```bash
   npm install
   npm run dev
   ```

Your app will be live at your Replit URL!

## For Local Development

1. **Prerequisites**
   - Node.js 18+
   - PostgreSQL
   - FFmpeg

2. **Setup**
   ```bash
   tar -xzf vetrecord-pro-v2.tar.gz
   cd vetrecord-pro
   npm install
   cp .env.example .env
   # Edit .env with your values
   psql -U postgres -f database-schema.sql
   npm run db:push
   npm run dev
   ```

## Getting API Keys

**OpenAI API Key:**
1. Go to https://platform.openai.com/api-keys
2. Create new secret key
3. Copy and add to your environment

**Session Secret:**
Generate a random string:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## Troubleshooting

- **Audio not working**: Check microphone permissions
- **Transcription fails**: Verify OpenAI API key and credits
- **Database errors**: Check DATABASE_URL connection string
- **FFmpeg errors**: Ensure FFmpeg is installed and in PATH